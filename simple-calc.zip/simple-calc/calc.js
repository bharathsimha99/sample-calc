const args = process.argv.slice(2);
const question = args.join(' ');

function calculate(question) {
  // Define a regular expression to match the input format
  const regex = /What is (\d+) (plus|minus|multiplied by|divided by) (\d+)\?/i;
  const match = question.match(regex);

  if (!match) {
    return null;
  }

  const [, num1, operator, num2] = match;

  // Perform calculations based on the operator
  let result;
  switch (operator.toLowerCase()) {
    case 'plus':
      result = parseInt(num1) + parseInt(num2);
      break;
    case 'minus':
      result = parseInt(num1) - parseInt(num2);
      break;
    case 'multiplied by':
      result = parseInt(num1) * parseInt(num2);
      break;
    case 'divided by':
      result = parseInt(num1) / parseInt(num2);
      break;
    default:
      result = null;
  }

  return result;
}

function main() {
  const result = calculate(question);

  if (result !== null) {
    console.log(`${question} is ${result}`);
  } else {
    console.error('Invalid input. Please provide a valid math question.');
  }
}

main();
